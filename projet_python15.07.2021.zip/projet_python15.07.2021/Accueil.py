from tkinter import  *
from  tkinter.filedialog import askopenfilename
from tkinter.messagebox import showerror,showinfo
from listedesInscrits import listInscrits


#Creation  d'une classe personnages contenant les différentes fonctions du programme
class Personnages():
    # fonction d'initialisation
    def __init__(self,prenom,nom,photo):
        self.prenom =prenom
        self.nom =nom
        self.photo =photo
    #eviter que deux personnes aient le même nom et prenoms
    def __eq__(self, other):
        return (self.prenom == other.prenom and self.nom == other.nom)

#definir la fonction permettant de choisir l'image dans la machine
def parcourir():
    global  imageName
    imn =askopenfilename(initialdir = "/",title="Selectionnez votre photo",filetypes =(("png files","*png"),("jpg files","*jpg"),("jpeg files ","*jpeg")))
    if imn :
        imageName = imn
    if imageName:
        texte = imageName.split("/")
        photoEntre.configure(text=".../"+texte[-1])
#creer la methode ou la fonction pour verifier si un personnage appartient ou non
def appartient(liste,val):
    for i in range(len(liste)):
        if liste[i].__eq__(val):
            return 1
    return  0

#creation de la fonction de validation des champs ou enregistrement des personnes
def valider():
    global  listepersonne,imageName
    photo =imageName
    if prenomEntre.get() and nomEntre.get() and photo:
        perso = Personnages(prenomEntre.get(),nomEntre.get(),photo)
        if appartient(listepersonne,perso):
            showerror(title="FORMULAIRE INVALIDE",message=" {} exite deja dans la liste".format(nomEntre.get()))
        else:
            listepersonne.append(perso)
            showinfo(title="AJOUT REUSSI",message=" {}  A ETE BIEN AJOUTE".format(prenomEntre.get()))
    else:
        showerror(title="FORMULAIRE INVALIDE", message=" Tous les champs doivent être renseignés")

#la fonction reinitialiser pour vider les champs de l'application
def reinitialiser ():
    global imageName
    prenomEntre.delete(0,END)
    nomEntre.delete(0,END)
    imageName =''
    photoEntre.configure(text="Aucune image selectionnée")
#initialisation des variables global utilisée
imageName,listepersonne ='',[]


fen = Tk()
fen.geometry("350x260+250+150")
fen.title("PAGE D'INSCRIPTION")
contenu = Canvas(fen,bg="#FF7800")


fontLabel = "arial 13 bold "
fontEntree = "arial 11 bold "
#creation des labels
prenom = Label(contenu, text="votre prenom : ", font=fontLabel, fg="white", bg ="#FF7800")
nom = Label(contenu, text="votre nom : ", font=fontLabel, fg="white", bg ="#FF7800")
photo = Label(contenu, text="votre photo : ", font=fontLabel, fg="white", bg ="#FF7800")
validation = Label(contenu, text=" ENTREZ VOS INFORMATIONS", font=fontLabel, fg="#FF7800", bg ="white")
#creation des zone de texte pour ecriture ou textfields
prenomEntre = Entry(contenu, font=fontEntree)
nomEntre = Entry(contenu, font=fontEntree)
photoEntre = Label(contenu, text="aucune photo selectionnée", font="arial 8 bold ", fg="#FF7800", bg ="white")
ButtonParcourir = Button(contenu, text="parcouri", command =parcourir,fg="white", bg ="#FF7800" )

#placer les label sur la fenetre créée avec la methode grid
validation.grid(row=0,column=0, columnspan=2)
prenom.grid(row=1,column=0,sticky =E, padx=5,pady=5)
nom.grid(row=2,column=0,sticky =E, padx=5,pady=5)
photo.grid(row=3,column=0,sticky =E, padx=5,pady=5)

#placer les textfields sur la fenetre  'FEN'
prenomEntre.grid(row=1,column=1, padx=5,pady=5)
nomEntre.grid(row=2,column=1, padx=5,pady=5)
photoEntre.grid(row=3,column=1, padx=5,pady=5, sticky=W)
ButtonParcourir.grid(row=3,column=1, padx=10,pady=10, sticky=E)

#Créationde pbouttons pour valider reinitialiser et voir la listes des inscrits
b1 = Button(contenu, text="Valider", command =valider, width = 10, fg="white", bg ="#FF7800")
b2 = Button(contenu, text="Reinitialiser", command =reinitialiser, width = 10, fg="white", bg ="#FF7800" )
b3 = Button(contenu, text="Voir la liste", command =lambda : listInscrits(fen,listepersonne), width = 10, fg="white", bg ="#FF7800" )

#placer les bouttons b1,b2,b3
b1.grid(row=4, column =0,pady=5)
b2.grid(row=5, column =0,pady=5)
b3.grid(row=6, column =0,pady=5)

contenu.grid(row=0, column =0 , padx=5, pady=5)
fen.mainloop()

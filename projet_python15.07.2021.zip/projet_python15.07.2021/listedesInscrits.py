from tkinter import  *
import  PIL.Image as IMG
import  PIL.ImageTk as IMTK
#from  PIL import  Image, ImageTK

#la fonction qui affiche les inscrits dans le tableau ou la liste
def listInscrits (fenetre,liste):
    newFen = Toplevel(fenetre)
    newFen.geometry("450x350+350+150")
    newFen.title("LISTE DES INSCRITS")

    listCan =Canvas(newFen,bg="#FF7800")
    fontLabel ="arial 11 bold"

    #creation des Labels pour l'affichage dans le tableau ou liste
    resultats =Label(listCan, text="votre prenom : ", font=fontLabel, fg="#FF7800", bg ="white")
    prenom = Label(listCan, text="prenom : ", width=15, font=fontLabel, fg="white", bg="#FF7800")
    nom = Label(listCan, text="nom : ",width=6, font=fontLabel, fg="white", bg="#FF7800")
    photo = Label(listCan, text="photo  : ", width=12, font=fontLabel, fg="white", bg="#FF7800")
    statut = Label(listCan, text="photo  : ", font="arial 9 bold", fg="white", bg="#FF7800")

    #placer les elements créer
    listCan.grid(row=0,column=0)
    resultats.grid(row=0,column=0,columnspan=3)
   # photo.grid(row=1,column=0,padx=5,pady=5)
    prenom.grid(row=1,column=1,padx=5,pady=5)
    nom.grid(row=1,column=2,padx=5,pady=5)
    statut.grid(row=2,column=0,columnspan=3)
    if liste:
         r=2
         for p in liste:
             labelPhoto = Label(listCan,height=80)
             img=IMG.open(p.photo)
             img=img.resize((80,80),IMG.ANTIALIAS)
             labelPhoto.img=IMTK.PhotoImage(img)

             pre= Label(listCan, text=p.prenom, font=fontLabel, fg="white", bg="#FF7800")
             no = Label(listCan, text=p.nom, font=fontLabel, fg="white", bg="#FF7800")

             labelPhoto.grid(row=r,column=0,pady=2)
             pre.grid(row=r, column=1)
             no.grid(row=r, column=2)
             listCan.create_line(9,55,355,55,width=1,fill="green")

             r+=1

             statut.configure(texte="{} INSCRITS SUR LA LISTE".format(len(liste)))
             statut.grid(row=r, column=0, columnspan=3, pady=2)

    newFen.mainloop()
